declare global {
  interface Window {
    _env_: {
      baseApiUrl?: string;
    };
  }
}

export {};

export const UnderConstruction = () => {
  return (
    <>
      <h1>🚧 Under construction 🚧</h1>
      <p>We're still working on this. Come back soon!</p>
    </>
  );
};

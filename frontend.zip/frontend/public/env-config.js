// This file should be overwritten with env vars in prod builds
// For dev builds, use .env and .env.local
window._env_ = {};

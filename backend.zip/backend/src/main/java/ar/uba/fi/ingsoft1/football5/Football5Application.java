package ar.uba.fi.ingsoft1.football5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Football5Application {

	public static void main(String[] args) {
		SpringApplication.run(Football5Application.class, args);
	}

}

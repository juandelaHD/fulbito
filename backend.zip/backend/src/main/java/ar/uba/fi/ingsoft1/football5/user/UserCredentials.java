package ar.uba.fi.ingsoft1.football5.user;

public interface UserCredentials {
    String getUsername();
    String getPassword();
}

package ar.uba.fi.ingsoft1.football5.user;

public enum Role {
    USER,
    ADMIN
}

package ar.uba.fi.ingsoft1.football5.matches;

public enum MatchType {
    OPEN,
    CLOSED
}
